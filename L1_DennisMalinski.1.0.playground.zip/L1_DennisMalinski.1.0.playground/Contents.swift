import Foundation

// Решить квадраратное уравнение.


let a:Float = 5
let b:Float = 10
let c:Float = 30
var x1: Float
var x2: Float
var d:Float
var discriminant:Float
d = b * b - (4 * a * c)
if (d >= 0){
    discriminant = sqrt(d)
    x1 = (-b + discriminant) / (2 * a)
    x2 = (-b - (discriminant)) / (2 * a)
    print(x1, x2)
}else if(d < 0){
    d = ((4 * a * c) - pow(b,2)) / (2 * a)
    print(d)
}

// Даны катеты прямоугольного треугольника. Найти площадь, периметр и гипотенузу треугольника.


var cathetusB: Float = 24
var cathetusC: Float = 38
var hypotenuse: Float
var perimeter: Float
var area: Float

hypotenuse = sqrt(pow(cathetusB,2) + pow(cathetusC,2))

perimeter = b + c + a

area = b * c / 2


print ("Гипотенуза \(hypotenuse)")
print ("Периметр \(perimeter)")
print ("Площадь \(area)")

// *Пользователь вводит сумму вклада в банк и годовой процент. Найти сумму вклада через 5 лет.

var deposit: Float = 100_000
var procent: Float = 4

var r = deposit / 100  * procent * 5 + deposit

print("Сумма вклада через 5 лет - \(r)₪")
